﻿namespace DecoratorDemo;

public class SimpleComponent
{
  private readonly string _text;
  public SimpleComponent(string text) => _text = text;

  public bool DoAddClock { get; set; }
  public string? Mask { get; set; } = null;
  public ConsoleColor Color { get; set; }
  public bool DoUseColor { get; set; }

  public void Operation()
  {
    if (DoAddClock) Console.Write($"{DateTime.Now:HH:mm:ss} ");
    if (Mask is not null) Console.Write(Mask);
    if (DoUseColor) Console.ForegroundColor = Color;
    Console.Write(_text);
    Console.ResetColor();
    if (Mask is not null) Console.Write(Mask);
  }
}
