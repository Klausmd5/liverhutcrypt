﻿using DecoratorDemo;

Console.WriteLine("--------------------------------------------- SimpleComponent");
var simpleComponent = new SimpleComponent("SimpleComponent")
{
  Mask = "*****",
  DoUseColor = true,
  Color = ConsoleColor.Cyan,
  DoAddClock = true
};
simpleComponent.Operation();
Console.WriteLine();

Console.WriteLine("--------------------------------------------- Decorators");
Console.ReadKey();
